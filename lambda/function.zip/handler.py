def handler(event, context):
    raise Exception("Simulated failure")
